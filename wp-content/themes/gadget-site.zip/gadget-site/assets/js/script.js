(function ($, w, d) {
  $(d).ready(function () {
  });

  $(w).on("load", function () {});
})(jQuery, window, document);